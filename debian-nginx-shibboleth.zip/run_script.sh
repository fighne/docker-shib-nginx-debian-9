#!/bin/bash
#

/etc/init.d/shibd restart
sleep 1
/etc/init.d/supervisor restart
sleep 1
/etc/init.d/nginx restart